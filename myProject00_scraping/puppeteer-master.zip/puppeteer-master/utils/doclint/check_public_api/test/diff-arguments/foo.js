class Foo {
  /**
   * @param {string} arg1
   */
  foo(arg1, arg3 = {}) {
  }

  /**
   * @param  {...string} filePaths
   */
  test(...filePaths) {
  }

  /**
   * @param {{visibility?: boolean}} options
   */
  bar(options) {
  }
}
