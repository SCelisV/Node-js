class Foo {
  return42() {
    return 42;
  }

  returnNothing() {
    let e = () => {
      return 10;
    }
    e();
  }

  www() {
    if (1 === 1)
      return 'df';
  }

  async asyncFunction() {
  }
}
