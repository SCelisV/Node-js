class A {
  constructor() {
  }

  foo(a) {
  }

  bar() {
  }
}

class B extends A {
  bar(override) {
  }
}
