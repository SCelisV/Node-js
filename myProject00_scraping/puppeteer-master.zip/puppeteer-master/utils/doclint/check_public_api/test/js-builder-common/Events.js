const Events = {
  A: {
    AnEvent: 'anevent'
  },
};
module.exports = { Events };
