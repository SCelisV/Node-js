module.exports = window.WebSocket;
