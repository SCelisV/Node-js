// Mock script for background extension
window.MAGIC = 42;
